<?php

// Template display name
$template_name = "G-Center";

// Append HTML headers
$extra_headers = '';

//$template_properties['demo'] = 'This demonstrates how you can add your own properties on your default template.';

?>