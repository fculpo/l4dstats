<?php
/*
================================================
LEFT 4 DEAD AND LEFT 4 DEAD 2 PLAYER RANK
Copyright (c) 2010 Mikko Andersson
================================================
Rank Award Listing - English - "awards.en.php"
================================================
*/

$award_killspitter = "<a href=\"%s\">%s</a> Don't Like Zombies Without Manners with <b>%s Spitter</b> kills.";
$award_killjockey = "<a href=\"%s\">%s</a> Likes To Be On Top with <b>%s Jockey</b> kills.";
$award_killcharger = "<a href=\"%s\">%s</a> Don't Like To Be Pushed Around with <b>%s Charger</b> kills.";

$award_adrenaline = "<a href=\"%s\">%s</a> Needs The Teammates To Stay In Top Speed with <b>%s Adrenalines Given</b>.";
$award_defib = "<a href=\"%s\">%s</a> is A Life Giver with <b>%s Defibrillators Used on Teammates</b>.";
$award_jockey = "<a href=\"%s\">%s</a> is The Freedom Fighter by <b>Saving %s Teammates From Jockeys</b>.";
$award_charger = "<a href=\"%s\">%s</a> is Giving Hell To Bullies <b>Saving %s Teammates From Chargers</b>.";

$award_matador = "<a href=\"%s\">%s</a> is The Matador with <b>%s Leveled Charges</b>.";
$award_scatteringram = "<a href=\"%s\">%s</a> is a Crowd Breaker with <b>%s Scattering Rams</b>.";
?>
